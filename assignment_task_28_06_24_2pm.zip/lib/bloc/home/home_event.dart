abstract class HomeEvent {}

class HomeFetchRepositoriesEvent extends HomeEvent {}

class HomeRefreshRepositoriesEvent extends HomeEvent {}

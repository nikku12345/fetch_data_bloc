class AppConfig{
  static String url="https://api.github.com";
  static String aapName="Assignment";
}
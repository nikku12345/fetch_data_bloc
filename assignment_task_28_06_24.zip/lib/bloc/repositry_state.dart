

import '../model/github_model.dart';

abstract class RepositoryState {}

class RepositoryLoadingState extends RepositoryState {}

class RepositoryLoadedState extends RepositoryState {
  final List<Repository> repositories;

  RepositoryLoadedState(this.repositories);
}

class RepositoryErrorState extends RepositoryState {}

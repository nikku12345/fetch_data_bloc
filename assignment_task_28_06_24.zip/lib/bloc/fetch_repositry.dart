import 'package:flutter/cupertino.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

import '../model/github_model.dart';


Future<List<Repository>> fetchRepositories() async {
  final response = await http.get(Uri.parse(
      'https://api.github.com/search/repositories?q=created:%3E2022-04-29&sort=stars&order=desc'));

  if (response.statusCode == 200) {
    final data = json.decode(response.body);
    debugPrint("response from api$data",wrapWidth: 1024);
    final List<Repository> repositories = (data['items'] as List)
        .map((item) => Repository.fromJson(item))
        .toList();
    print("response of repo$repositories");
    return repositories;
  } else {
    throw Exception('Failed to load repositories');
  }
}

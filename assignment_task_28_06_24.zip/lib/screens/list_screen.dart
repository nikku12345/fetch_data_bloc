import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../bloc/bloc_repositry.dart';
import '../bloc/repositry_event.dart';
import '../bloc/repositry_state.dart';


class RepositoryListScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('GitHub Repositories')),
      body: BlocBuilder<RepositoryBloc, RepositoryState>(
        builder: (context, state) {
          if (state is RepositoryLoadingState) {
            return const Center(child: CircularProgressIndicator());
          } else if (state is RepositoryLoadedState) {
            return RefreshIndicator(
              onRefresh: () async {
                context.read<RepositoryBloc>().add(RefreshRepositoriesEvent());
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Data refresh completed')),
                );
              },
              child: ListView.builder(
                itemCount: state.repositories.length,
                itemBuilder: (context, index) {
                  final repo = state.repositories[index];
                  return ListTile(
                    title: Text(repo.name),
                    subtitle: Text(repo.description ?? 'No description'),
                    trailing: Text('${repo.stargazersCount} ⭐'),

                  );
                },
              ),
            );
          } else if (state is RepositoryErrorState) {
            return const Center(child: Text('Failed to load repositories. Please check your internet connection and try again.'));
          }
          return Container();
        },
      ),
    );
  }
}

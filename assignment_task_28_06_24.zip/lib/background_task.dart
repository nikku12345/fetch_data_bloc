import 'dart:isolate';

import 'bloc/fetch_repositry.dart';
import 'helper/database_helper.dart';


Future<void> refreshRepositories(DatabaseHelper databaseHelper) async {
  final ReceivePort receivePort = ReceivePort();
  await Isolate.spawn(_refreshRepositoriesIsolate, receivePort.sendPort);

  final SendPort sendPort = await receivePort.first;
  final response = ReceivePort();
  sendPort.send([response.sendPort, databaseHelper]);

  await for (final message in response) {
    if (message == 'done') {
      break;
    }
  }
}

void _refreshRepositoriesIsolate(SendPort sendPort) async {
  final port = ReceivePort();
  sendPort.send(port.sendPort);

  await for (final message in port) {
    final SendPort replyTo = message[0];
    final DatabaseHelper databaseHelper = message[1];

    try {
      var repositories = await fetchRepositories();
      await databaseHelper.insertRepositories(repositories);
    } catch (e) {
      // Handle error if needed
    }

    replyTo.send('done');
  }
}

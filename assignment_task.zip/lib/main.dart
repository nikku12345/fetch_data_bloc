import 'package:assignment_task/screens/list_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'bloc/bloc_repositry.dart';
import 'bloc/repositry_event.dart';
import 'helper/database_helper.dart';


void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'GitHub Repositories',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: BlocProvider(
        create: (context) => RepositoryBloc(DatabaseHelper())..add(FetchRepositoriesEvent()),
        child: RepositoryListScreen(),
      ),
    );
  }
}

import 'package:assignment_task/bloc/repositry_event.dart';
import 'package:assignment_task/bloc/repositry_state.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../background_task.dart';
import '../helper/database_helper.dart';
import 'fetch_repositry.dart';


class RepositoryBloc extends Bloc<RepositoryEvent, RepositoryState> {
  final DatabaseHelper databaseHelper;

  RepositoryBloc(this.databaseHelper) : super(RepositoryLoadingState()) {
    on<FetchRepositoriesEvent>((event, emit) async {
      emit(RepositoryLoadingState());
      try {
        List<Map<String, dynamic>> repositories = await databaseHelper.getRepositories();
        if (repositories.isEmpty) {
          repositories = await fetchRepositories();
          await databaseHelper.insertRepositories(repositories);
        }
        emit(RepositoryLoadedState(repositories));
      } catch (e) {
        emit(RepositoryErrorState());
      }
    });

    on<RefreshRepositoriesEvent>((event, emit) async {
      emit(RepositoryLoadingState());
      try {
        await refreshRepositories(databaseHelper);
        List<Map<String, dynamic>> repositories = await databaseHelper.getRepositories();
        emit(RepositoryLoadedState(repositories));
      } catch (e) {
        emit(RepositoryErrorState());
      }
    });
  }
}

abstract class RepositoryEvent {}

class FetchRepositoriesEvent extends RepositoryEvent {}

class RefreshRepositoriesEvent extends RepositoryEvent {}

abstract class RepositoryState {}

class RepositoryLoadingState extends RepositoryState {}

class RepositoryLoadedState extends RepositoryState {
  final List<Map<String, dynamic>> repositories;

  RepositoryLoadedState(this.repositories);
}

class RepositoryErrorState extends RepositoryState {}

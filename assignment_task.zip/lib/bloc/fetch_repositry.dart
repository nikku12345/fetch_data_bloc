import 'package:http/http.dart' as http;
import 'dart:convert';

Future<List<Map<String, dynamic>>> fetchRepositories() async {
  final response = await http.get(Uri.parse(
      'https://api.github.com/search/repositories?q=created:%3E2022-04-29&sort=stars&order=desc'));

  if (response.statusCode == 200) {
    final data = json.decode(response.body);
    final List<Map<String, dynamic>> repositories = (data['items'] as List)
        .map((item) => {
      'name': item['name'],
      'full_name': item['full_name'],
      'html_url': item['html_url'],
      'description': item['description'],
      'stargazers_count': item['stargazers_count']
    })
        .toList();
    return repositories;
  } else {
    throw Exception('Failed to load repositories');
  }
}

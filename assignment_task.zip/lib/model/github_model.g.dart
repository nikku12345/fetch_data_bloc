// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'github_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

Repository _$RepositoryFromJson(Map<String, dynamic> json) => Repository(
      name: json['name'] as String,
      fullName: json['fullName'] as String,
      htmlUrl: json['htmlUrl'] as String,
      description: json['description'] as String?,
      stargazersCount: (json['stargazersCount'] as num).toInt(),
    );

Map<String, dynamic> _$RepositoryToJson(Repository instance) =>
    <String, dynamic>{
      'name': instance.name,
      'fullName': instance.fullName,
      'htmlUrl': instance.htmlUrl,
      'description': instance.description,
      'stargazersCount': instance.stargazersCount,
    };
